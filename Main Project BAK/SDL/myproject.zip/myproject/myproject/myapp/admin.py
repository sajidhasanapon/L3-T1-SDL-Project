from django.contrib import admin
from myproject.myapp.models import Document
admin.site.register(Document)
# Register your models here.
